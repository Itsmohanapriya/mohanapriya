unsigned char read_digital_keypad();
void ssd_display(unsigned char SSD[]); 
void int_to_str(unsigned int, unsigned char);
#define ALL_RELEASED 0X0F
#define SWITCH1 0X0E
#define SWITCH2 0X0D
#define SWITCH3 0X0B
#define SWITCH4 0X07