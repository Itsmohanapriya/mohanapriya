void init_timer0();
void __interrupt() isr();