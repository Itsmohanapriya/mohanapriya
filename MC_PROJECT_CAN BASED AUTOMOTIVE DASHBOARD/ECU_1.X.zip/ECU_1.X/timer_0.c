#include<xc.h>
#include"timer_0.h"
void init_timer0()
{
    // Timer0 internal clock
    T0CS = 0;
    T0CONbits.T08BIT = 0;    // 16-bit mode

    // Prescaler assigned
      T0CONbits.PSA = 0;       // Prescaler ON

    // Prescaler = 1:32
    T0CONbits.T0PS2 = 1;
    T0CONbits.T0PS1 = 0;
    T0CONbits.T0PS0 = 0;

    // Prescaler assign to Timer0

    // Reload for 1ms timing
    TMR0H = 0xEC;
    TMR0L = 0x78;

    // Interrupt enable
    TMR0IE = 1;
    PEIE = 1;
    GIE = 1;
    TMR0IF = 0;
}

void __interrupt() ISR()
{
    static unsigned int count = 0;

    if (TMR0IF)
    {
        TMR0H = 0xEC;
        TMR0L = 0x78;

        ms_count++;       // << FIX for 1 second update

        count++;
        if (count == 50)
        {
            count = 0;
            blink_flag ^= 1;
        }

        TMR0IF = 0;
    }
}