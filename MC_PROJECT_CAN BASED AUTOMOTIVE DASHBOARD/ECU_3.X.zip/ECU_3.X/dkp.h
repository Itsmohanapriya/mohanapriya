unsigned char read_digital_keypad(unsigned char detection_type);
#define EDGE 1