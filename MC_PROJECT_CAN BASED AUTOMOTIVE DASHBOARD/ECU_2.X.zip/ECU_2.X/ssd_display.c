#include<xc.h>
#include"ssd_display.h"
unsigned char read_digital_keypad(unsigned char detection_type)                    //function to keypad pressed 
{
    static int once = 1;
    if(detection_type == EDGE)
    {
    if(((PORTC & 0x0F) != 0X0F) && (once == 1))
    {
        once = 0;
        return PORTC & 0x0F;
    }
    else if((PORTC & 0x0F) == 0X0F)
    {
        once = 1;
    }
    }
    return 0X0F;
}

void ssd_display(unsigned char SSD[])                   // Function to display 4 digits on multiplexed seven segment display
{
    for (int i = 0; i < 4; i++)                         // Loop through all 4 SSD digits
    {
        PORTD = SSD[i];                                 // Send segment pattern of current digit to PORTD
        PORTA = (PORTA & 0xF0) | (1 << i);              // Enable corresponding SSD by activating its select line
        for (int wait = 1000; wait--; );                // Small delay to keep the digit visible (for persistence of vision)
    }
}