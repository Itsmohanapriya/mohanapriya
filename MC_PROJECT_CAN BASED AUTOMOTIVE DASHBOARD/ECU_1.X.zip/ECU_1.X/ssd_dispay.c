#include<xc.h>
#include"ssd_display.h"
unsigned char read_digital_keypad()                    //function to keypad pressed 
{
        return (PORTC & 0X0F);                          //return the pressed switch value
}
void ssd_display(unsigned char SSD[])                   // Function to display 4 digits on multiplexed seven segment display
{
    for (int i = 0; i < 4; i++)                         // Loop through all 4 SSD digits
    {
        PORTD = SSD[i];                                 // Send segment pattern of current digit to PORTD
        PORTA = (PORTA & 0xF0) | (1 << i);              // Enable corresponding SSD by activating its select line
        for (int wait = 1000; wait--; );                // Small delay to keep the digit visible (for persistence of vision)
    }
}