#include<xc.h>
#include"dkp.h"
unsigned char read_digital_keypad(unsigned char detection_type)                    //function to keypad pressed 
{
    static int once = 1;
    if(detection_type == EDGE)
    {
    if(((PORTC & 0x0F) != 0X0F) && (once == 1))
    {
        once = 0;
        return PORTC & 0x0F;
    }
    else if((PORTC & 0x0F) == 0X0F)
    {
        once = 1;
    }
    }
    return 0X0F;
}
