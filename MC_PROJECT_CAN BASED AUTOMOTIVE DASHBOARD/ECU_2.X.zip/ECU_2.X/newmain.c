/*
 * File:   newmain.c
 * Author: Mohanapriya
 *
 * Created on 4 December, 2025, 9:13 AM
 */


#include <xc.h>
#include"adc.h"
#include"ssd_display.h"
#include"can.h"
#include"clcd.h"
#include"msg_id.h"
#include"mkp.h"
// Gear mapping table
const char *gear_table[] = {"N", "1", "2", "3", "4", "5", "R"};

#define _XTAL_FREQ 20000000

void init_config()
{
    // DKP RC4?RC7 input
    TRISC |= 0xF0;

    // CLCD control RC0?RC2 output
    //TRISC &= 0xF8;

    // CLCD data PORTD output
    TRISD = 0x00; 
    init_adc();
    init_can();
    init_clcd();
    //init_matrix_keypad();
}
void main(void) 
{
     init_config();
    
    unsigned int adc_reg_val;
    unsigned int speed = 0;
    unsigned char key;

    unsigned char speed_buf[5];
    unsigned char gear_index = 0;   // 0=N, 1?5 gears, 6=R

    uint16_t msg_id;
    uint8_t data[8];
    uint8_t data1[8];
    uint8_t len = 0;
    
    while (1)
    {
       adc_reg_val = read_adc(CHANNEL4);
       speed = (adc_reg_val / 10.23);
       
       speed_buf[0] = (speed / 100) + '0';
       speed_buf[1] = ((speed % 100) / 10) + '0';
       speed_buf[2] = (speed % 10) + '0';
       speed_buf[3] = '\0';
       
        /* ---------------------- CAN TRANSMIT ---------------------- */
        can_transmit(SPEED_MSG_ID, speed_buf, 3);
        __delay_ms(30);
        clcd_print("T-S:",LINE1(0));
        //clcd_print(speed_buf , LINE1(5));
//        can_receive(&msg_id,data1 ,&len);
//        data1[len] = '\0';
//        __delay_ms(30);
//        clcd_print("R-S:",LINE2(0));
//        clcd_print((char *)data1 , LINE2(5));
        
       
        /* ---------------------- KEYPAD FOR GEAR ------------------- */
        /*key = read_switches(STATE_CHANGE);

        if(key == MK_SW1)        // gear ++
        {
            if(gear_index < 6)
                gear_index++;
        }
        else if(key == MK_SW2)   // gear --
        {
            if(gear_index > 0)
                gear_index--;
        }*/
        key = read_switches();

        if(key == SWITCH1)        // gear ++
        {
            if(gear_index < 6)
                gear_index++;
        }
        else if(key == SWITCH2)   // gear --
        {
            if(gear_index > 0)
                gear_index--;
        }
        
        can_transmit(GEAR_MSG_ID, (uint8_t*)gear_table[gear_index], 1);
        __delay_ms(30);
        clcd_print(gear_table[gear_index] , LINE1(13));
        clcd_print((char*)gear_table[gear_index], LINE1(10));
        clcd_print("T-G:",LINE1(10));
//        can_receive(&msg_id,data1 ,&len);
//        __delay_ms(30);
//        clcd_print("R-G:",LINE2(10));
//        clcd_putch(data1[0], LINE2(14));
    }
}
              
    

