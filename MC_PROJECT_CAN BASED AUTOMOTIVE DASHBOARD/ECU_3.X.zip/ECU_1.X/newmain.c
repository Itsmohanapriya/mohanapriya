/*
 * File:   newmain.c
 * Author: Mohanapriya
 *
 * Created on 3 December, 2025, 5:37 PM
 */


#include <xc.h>
#include"adc.h"
#include"ssd_display.h"
#include"can.h"
#include"msg_id.h"
#include"clcd.h"
#include"mkp.h"
void init_config()
{    

    TRISB = 0x00;       // LEDs output
    PORTB = 0x00;
     
    TRISC |= 0x0F; // Keypad input 
    //TRISD = 0x00; // SSD data 
    //TRISA &= 0xF0; // SSD select pins RA0-RA3 
    init_adc();
    init_clcd();
    init_can(); 
    init_matrix_keypad();
}

void main(void) 
{
    unsigned int adc_reg_val;
    unsigned char key,buf[5];
    unsigned long result = 0;
    uint16_t msg_id;
    uint8_t data[8];
    uint8_t len = 0;
    uint8_t indicator = 0;

    init_config();
    while (1)
    {
        adc_reg_val = read_adc(CHANNEL4);
        result = (adc_reg_val / 10.23) * 60;

        // Convert and transmit CAN
        buf[0] = (result / 1000) + '0';
        buf[1] = ((result % 1000) / 100) + '0';
        buf[2] = ((result % 100) / 10) + '0';
        buf[3] = (result % 10) + '0';
        buf[4] = '\0';

        can_transmit(RPM_MSG_ID, buf, 4);
        
        /*clcd_print("TX",LINE1(0));
        clcd_print(buf,LINE1(4));
        //delay
        for(int i=0;i<5000;i++);
        // Receive CAN
        can_receive(&msg_id, data, &len);
        data[4] = '\0';
        clcd_print("RX",LINE2(0));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
            if(len == 4 && msg_id == RPM_MSG_ID) 
            {  
               clcd_print((char*)data,LINE2(4));
            } */
        /*key = read_switches(STATE_CHANGE);
        if(key == MK_SW1)      // MKP1
        {
            indicator = 0;
            clcd_print("<- ",LINE2(12));           
        }
        else if(key == MK_SW2) // DKP2
        {
            indicator = 1;
            clcd_print(" ->",LINE2(12));           
        }
        else if(key == MK_SW3) // DKP3
        {
            indicator = 2;
            clcd_print(" - ",LINE2(12));           
        }
        else if(key == MK_SW4) // DKP4
        {
            indicator = 3;
            clcd_print("<->",LINE2(12));           
        }*/
        
        key = read_digital_keypad() ;
        if(key == SWITCH1)      // MKP1
        {
            indicator = 0;
            //clcd_print("<- ",LINE2(12));           
        }
        else if(key == SWITCH1) // DKP2
        {
            indicator = 1;
            //clcd_print(" ->",LINE2(12));           
        }
        else if(key == SWITCH1) // DKP3
        {
            indicator = 2;
            //clcd_print(" - ",LINE2(12));           
        }
        else if(key == SWITCH1) // DKP4
        {
            indicator = 3;
            //clcd_print("<->",LINE1(12));           
        }
        can_transmit(INDICATOR_MSG_ID, &indicator, 1);
        
        /*for(int i=0;i<5000;i++);
        
        can_receive(&msg_id,data,&len);
        clcd_print("IN", LINE2(9));
       if(msg_id == INDICATOR_MSG_ID && len == 3)
      {
         switch(data[0])
       {
        case 0: 
            clcd_print("<- ",LINE2(12)); 
            break;
        case 1: 
            clcd_print("-> ",LINE2(12)); 
            break;
        case 2: 
            clcd_print("-  ",LINE2(12)); 
            break;
        case 3: 
            clcd_print("<->",LINE2(12)); 
            break;
        default: break;
      }
    }*/
        
        

      
    }
        
}
    