/*
 * File:   newmain.c
 * Author: Mohanapriya
 *
 * Created on 3 December, 2025, 5:37 PM
 */


#include <xc.h>
#include"adc.h"
#include"ssd_display.h"
#include"can.h"
#include"msg_id.h"
#include"clcd.h"
void init_config()
{    

    TRISB = 0x00;       // LEDs output
    PORTB = 0x00;
     
    //TRISC |= 0x0F; // Keypad input 
    //TRISD = 0x00; // SSD data 
    //TRISA &= 0xF0; // SSD select pins RA0-RA3 
    init_adc();
    init_clcd();
    init_can(); 
     
}

void main(void) 
{
    unsigned int adc_reg_val;
    unsigned char key,buf[5];
    unsigned long result = 0;
    uint16_t msg_id;
    uint8_t data[8];
    uint8_t len = 0;

    init_config();
    while (1)
    {
        adc_reg_val = read_adc(CHANNEL4);
        result = (adc_reg_val / 10.23) * 60;

        // Convert and transmit CAN
        buf[0] = (result / 1000) + '0';
        buf[1] = ((result % 1000) / 100) + '0';
        buf[2] = ((result % 100) / 10) + '0';
        buf[3] = (result % 10) + '0';
        buf[4] = '\0';
        clcd_print("Trans",LINE1(0));
        clcd_print(buf, LINE2(0));

        can_transmit(RPM_MSG_ID, buf, 4);
        //delay
        for(int i=0;i<5000;i++);
        // Receive CAN
            can_receive(&msg_id, data, &len);
            data[4] = '\0';
            clcd_print("-> Rece", LINE1(6));

            if(len == 4 && msg_id == RPM_MSG_ID) 
            {  
               clcd_print((char*)data, LINE2(6));
            }  

        /*key = read_digital_keypad();
        if(key == SWITCH1)      // DKP1
            PORTB = 0X01;
        else if(key == SWITCH2) // DKP2
            PORTB = 0X02;
        else if(key == SWITCH3) // DKP3
            PORTB = 0X00;
        else if(key == SWITCH4) // DKP4
            PORTB = 0X03;*/
        
      
    }
        
}
    