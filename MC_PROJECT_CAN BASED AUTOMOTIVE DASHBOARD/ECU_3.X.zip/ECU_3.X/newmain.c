/*
 * File:   newmain.c
 * Author: Mohanapriya
 *
 * Created on 10 December, 2025, 9:25 PM
 */



#include <xc.h>
#include"adc.h"
#include"can.h"
#include"msg_id.h"
#include"clcd.h"
#include"dkp.h"
#include<stdio.h>

void init_config()
{    
    init_adc();
    init_clcd();
    init_can(); 
}

void main(void) 
{
    uint16_t msg_id;
    uint8_t data[8];
    uint8_t len = 0;
    uint8_t indicator = 0;
    init_config();
    //clcd_print("RPM",LINE2(0));
    while(1)
    {
        can_receive(&msg_id, data, &len);
        char value[6] ;
        sprintf(value , "%d" , msg_id);
        
        clcd_print(value,LINE2(0));
        if(msg_id == RPM_MSG_ID)
        {
        //clcd_print("RPM",LINE2(0));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
            if(len == 4 && msg_id == RPM_MSG_ID) 
            {  
               clcd_print((char*)data,LINE2(0));
            } 
        }
        else if(msg_id == INDICATOR_MSG_ID)
        {
            clcd_print("IND", LINE2(13));
            if(msg_id == INDICATOR_MSG_ID && len == 3)
            {
               switch(data[0])
              {
                case 0: 
                clcd_print("<- ",LINE2(12)); 
                break;
                case 1: 
                clcd_print("-> ",LINE2(12)); 
                break;
                case 2: 
                clcd_print("-  ",LINE2(12)); 
                break;
                case 3: 
                clcd_print("<->",LINE2(12)); 
                break;
                default: break;
             }
           }
        }
        else if(msg_id == SPEED_MSG_ID)
        {
          data[3] = '\0';   // terminate the string
          clcd_print("R-S:",LINE2(0));
          clcd_print((char*)data,LINE2(4));
        }
     //clcd_print("R-G:", LINE2(8));
        else if(msg_id == GEAR_MSG_ID && len == 1)
        {
           clcd_print("R-G:",LINE2(8));
           clcd_putch(data[0],LINE2(13));
        }
        
    }
}

