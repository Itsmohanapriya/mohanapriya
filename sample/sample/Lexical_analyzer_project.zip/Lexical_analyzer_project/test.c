#include<stdio.h>
int main()
{
    int a = 5;
    int b= 0x74;
    int c = a+b;
    printf("%d",c);
}