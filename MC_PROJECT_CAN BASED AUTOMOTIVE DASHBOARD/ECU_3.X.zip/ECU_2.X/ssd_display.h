unsigned char read_digital_keypad(unsigned char detection_type);
void ssd_display(unsigned char SSD[]); 
#define ALL_RELEASED 0X0F
#define SWITCH1 0X0E
#define SWITCH2 0X0D
#define EDGE 1